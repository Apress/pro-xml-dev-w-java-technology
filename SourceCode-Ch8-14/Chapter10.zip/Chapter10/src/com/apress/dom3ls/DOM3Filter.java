package com.apress.dom3ls;

import org.w3c.dom.*;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.*;
import org.w3c.dom.traversal.*;

import java.io.*;

public class DOM3Filter {
                              // Method to filter an input document and an output document.
	public void filter() {
		try {
                                      //Set DOMImplementationRegistry object
	                         System.setProperty(DOMImplementationRegistry.PROPERTY,
				"org.apache.xerces.dom.DOMImplementationSourceImpl");
                                       //Create  a DOMImplementationRegistry object
			DOMImplementationRegistry registry = DOMImplementationRegistry
					.newInstance();
                                       //Create a DOMImplementation object
			DOMImplementation domImpl = registry
					.getDOMImplementation("XML 3.0");
                                       //Create a DOMImplementationLS object
			DOMImplementationLS impl = (DOMImplementationLS) domImpl;
                                       //Create a LSParser object
			LSParser parser = impl.createLSParser(
				DOMImplementationLS.MODE_SYNCHRONOUS, null);
                                        //Filter Input
			LSInput input = impl.createLSInput();
			InputStream inputStream = new FileInputStream(new File(
					"catalog.xml"));
			input.setByteStream(inputStream);

			InputFilter inputFilter = new InputFilter();
			parser.setFilter(inputFilter);

			Document document = parser.parse(input);
                                       //Create a LSSerializer object
			LSSerializer domWriter = impl.createLSSerializer();
                                       //Set an output Filter
			OutputFilter outputFilter = new OutputFilter();
			domWriter.setFilter(outputFilter);

			LSOutput lsOutput = impl.createLSOutput();
			
			lsOutput.setByteStream(System.out);
			System.out.println("\n"+"Filtered Document"+"\n");
                                        //Filter output
			domWriter.write(document, lsOutput);
		} catch (IOException e) {
			System.err.println(e);
		} catch (ClassNotFoundException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
	}

	public static void main(String[] args) {
		DOM3Filter dom3Filter = new DOM3Filter();
		dom3Filter.filter();
	}
                   //Input filter class
	private class InputFilter implements LSParserFilter {
		public short acceptNode(Node node) {
			return NodeFilter.FILTER_ACCEPT;
		}

		public int getWhatToShow() {
			return NodeFilter.SHOW_ELEMENT;
		}

		public short startElement(Element element) {
			System.out.println("Element Parsed " + element.getTagName());

			return NodeFilter.FILTER_ACCEPT;
		}
	}
                     //Output filter class
	private class OutputFilter implements LSSerializerFilter {
		public short acceptNode(Node node) {
			Element element = (Element) node;

			if (element.getTagName().equals("journal")) {
				if (element.getAttribute("date").equals("April 2005")) {
					return NodeFilter.FILTER_REJECT;
				}
			}

			return NodeFilter.FILTER_ACCEPT;
		}

		public int getWhatToShow() {
			return NodeFilter.SHOW_ELEMENT;
		}
	}
}
