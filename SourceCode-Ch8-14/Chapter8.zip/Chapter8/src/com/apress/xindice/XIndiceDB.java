package com.apress.xindice;

import org.apache.xindice.client.xmldb.services.*;
import org.apache.xindice.util.XindiceException;
import org.apache.xindice.xml.dom.*;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import org.xmldb.api.*;
import org.xmldb.api.base.*;
import org.xmldb.api.modules.*;
import java.io.*;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

public class XIndiceDB {
	private Collection collection;

	private Collection catalogCollection;

	String resourceID;

public void createCollection() {
		try {
			String xindiceDriver = "org.apache.xindice.client.xmldb.DatabaseImpl";
			Database xindiceDatabase = (Database) ((Class
					.forName(xindiceDriver)).newInstance());
			DatabaseManager.registerDatabase(xindiceDatabase);

			String url = "xmldb:xindice://localhost:8080/db";
			collection = DatabaseManager.getCollection(url);

			String collectionName = "catalog";
			CollectionManager collectionManagerService = (CollectionManager) collection
					.getService("CollectionManager", "1.0");

			String collectionConfig = "<collection compressed=\"true\" "
					+ "            name=\""
					+ collectionName
					+ "\">"
					+ "   <filer class=\"org.apache.xindice.core.filer.BTreeFiler\"/>"
					+ "</collection>";

			catalogCollection = collectionManagerService.createCollection(
					collectionName, DOMParser.toDocument(collectionConfig));
            System.out.println("XIndice Collection Created");
		} catch (XindiceException e) {
		} catch (XMLDBException e) {
		} catch (ClassNotFoundException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
	}public void addDocument() {
		try {
			String xindiceDriver = "org.apache.xindice.client.xmldb.DatabaseImpl";
			Database xindiceDatabase = (Database) ((Class
					.forName(xindiceDriver)).newInstance());
			DatabaseManager.registerDatabase(xindiceDatabase);
			collection = DatabaseManager
					.getCollection("xmldb:xindice://localhost:8080/db/catalog");

			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();

			File datafile = new File("xindice-resources/catalog.xml");

			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(datafile);

			resourceID = collection.createId();

			XMLResource resource = (XMLResource) (collection.createResource(
					resourceID, "XMLResource"));
			resource.setContentAsDOM(document);

			collection.storeResource(resource);
			System.out.println("XML Document Added to Collection");
		} catch (SAXException e) {
		} catch (ParserConfigurationException e) {
		} catch (XMLDBException e) {
			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (InstantiationException e) {
			System.out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			System.out.println(e.getMessage());
		}
	}	public void retrieveDocument() {
		try {
			XMLResource resource = (XMLResource) (collection
					.getResource(resourceID));

			System.out.println(resource.getContent());
		} catch (XMLDBException e) {
		}
	}

public void queryDocument() {
		try {
			String xpath = "/catalog/journal[1]/article/title";
			XPathQueryService queryService = (XPathQueryService) collection
					.getService("XPathQueryService", "1.0");
			ResourceSet resourceSet = queryService.query(xpath);
			ResourceIterator iterator = resourceSet.getIterator();
			System.out.println("XPath Query");
			while (iterator.hasMoreResources()) {
				Resource resource = iterator.nextResource();
				System.out.println(resource.getContent());
			}
		} catch (XMLDBException e) {
		}
	}public void updateDocument() {
		try {
			String xindiceDriver = "org.apache.xindice.client.xmldb.DatabaseImpl";
			Database xindiceDatabase = (Database) ((Class
					.forName(xindiceDriver)).newInstance());
			DatabaseManager.registerDatabase(xindiceDatabase);
			collection = DatabaseManager
					.getCollection("xmldb:xindice://localhost:8080/db/catalog");

			String xupdate = "<xupdate:modifications version=\"1.0\""
					+ "    xmlns:xupdate=\"http://www.xmldb.org/xupdate\">"
					+ "    <xupdate:insert-after select=\"/catalog/journal[3]\">"
					+ "    <journal date=\"Aug 2005\">" + "    <article>"
					+ "    <title>iBatis DAO</title>"
					+ "    <author>Sunil Patil</author>" + "    </article>"
					+ "    </journal>" + "    </xupdate:insert-after>"
					+ "</xupdate:modifications>";

			XUpdateQueryService queryService = (XUpdateQueryService) collection
					.getService("XUpdateQueryService", "1.0");
			queryService.update(xupdate);

			xupdate = "<xupdate:modifications version=\"1.0\""
					+ "    xmlns:xupdate=\"http://www.xmldb.org/xupdate\">"
					+ "    <xupdate:remove select=\"/catalog/journal[1]\"/>"
					+ "</xupdate:modifications>";

			queryService.update(xupdate);

			xupdate = "<xupdate:modifications version=\"1.0\""
					+ "    xmlns:xupdate=\"http://www.xmldb.org/xupdate\">"
					+ "    <xupdate:update select=\"/catalog/journal[2]/article/title\">Maven with Swing</xupdate:update>"
					+ "</xupdate:modifications>";

			queryService.update(xupdate);

			XMLResource resource = (XMLResource) (collection
					.getResource(resourceID));
			System.out.println("Updated XML Document");
			System.out.println(resource.getContent());
		} catch (XMLDBException e) {
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		} catch (InstantiationException e) {
			System.out.println(e.getMessage());
		} catch (IllegalAccessException e) {
			System.out.println(e.getMessage());
		}
	}public void deleteDocument() {
		try {
			XMLResource resource = (XMLResource) (collection
					.getResource(resourceID));
			collection.removeResource(resource);
			System.out.println("XML Document Deleted");
		} catch (XMLDBException e) {
		}
	}	public static void main(String[] argv) {
		XIndiceDB xindicedb = new XIndiceDB();
		xindicedb.createCollection();

		xindicedb.addDocument();
		xindicedb.retrieveDocument();
		xindicedb.queryDocument();
		xindicedb.updateDocument();
		xindicedb.deleteDocument();
	}
}
