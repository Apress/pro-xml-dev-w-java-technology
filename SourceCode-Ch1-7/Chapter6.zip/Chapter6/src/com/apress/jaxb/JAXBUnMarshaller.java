package com.apress.jaxb;

import generated.*;
import generated.impl.*;
import generated.impl.runtime.*;
import javax.xml.bind.*;
import java.io.File;
import java.io.IOException;

public class JAXBUnMarshaller {
	public void unMarshall(File xmlDocument) {
		try {

			JAXBContext jaxbContext = JAXBContext.newInstance("generated");

			Unmarshaller unMarshaller = jaxbContext.createUnmarshaller();

			unMarshaller.setValidating(true);

			Catalog catalog = (Catalog) unMarshaller.unmarshal(xmlDocument);

			System.out.println("Section: " + catalog.getSection());
			System.out.println("Publisher: " + catalog.getPublisher());
			java.util.List journalList = catalog.getJournal();
			for (int i = 0; i < journalList.size(); i++) {

				Journal journal = (Journal) journalList.get(i);

				java.util.List articleList = journal.getArticle();
				for (int j = 0; j < articleList.size(); j++) {
					Article article = (Article) articleList.get(j);

					System.out.println("Article Date: " + article.getDate());
					System.out.println("Level: " + article.getLevel());
					System.out.println("Title: " + article.getTitle());
					System.out.println("Author: " + article.getAuthor());

				}
			}
		} catch (JAXBException e) {
			System.out.println(e.toString());
		}
	}

	public static void main(String[] argv) {
		File xmlDocument = new File("catalog.xml");
		JAXBUnMarshaller jaxbUnmarshaller = new JAXBUnMarshaller();
		jaxbUnmarshaller.unMarshall(xmlDocument);
	}
}
