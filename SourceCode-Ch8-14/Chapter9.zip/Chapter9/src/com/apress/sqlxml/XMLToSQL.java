package com.apress.sqlxml;

import java.sql.*;
import javax.xml.stream.*;
import java.io.InputStream;
import javax.xml.transform.stax.StAXResult;

public class XMLToSQL {
	Connection connection;

	public void createJDBCConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");

			String url = "jdbc:mysql://localhost:3306/test";

			Connection connection = DriverManager.getConnection(url, "sa", "sqlserver");

			DatabaseMetaData metadata = connection.getMetaData();
			ResultSet rs = metadata.getTypeInfo();
			rs.next();

			while (rs.next()) {
				System.out.println("TYPE_NAME:" + rs.getString("TYPE_NAME"));

			}
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
		}
	}

	public void storeXMLDocument() {

		try {

			SQLXML sqlXML = connection.createSQLXML();
			StAXResult staxResult = sqlXML.setResult(StAXResult.class);
			XMLStreamWriter xmlStreamWriter = staxResult.getXMLStreamWriter();

			

			xmlStreamWriter.writeStartDocument("UTF-8", "1.0");
			xmlStreamWriter.writeStartElement("catalog");
			xmlStreamWriter.writeAttribute("title", "ONJava.com");
			xmlStreamWriter.writeAttribute("publisher", "OReilly");

			xmlStreamWriter.writeStartElement("journal");
			xmlStreamWriter.writeAttribute("date", "September 2005");
			xmlStreamWriter.writeStartElement("article");

			xmlStreamWriter.writeStartElement("title");
			xmlStreamWriter.writeCharacters("What Is a Portlet");
			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeStartElement("author");
			xmlStreamWriter.writeCharacters("Sunil Patil");
			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeStartElement("article");

			xmlStreamWriter.writeStartElement("title");
			xmlStreamWriter.writeCharacters("What Is Hibernate");
			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeStartElement("author");
			xmlStreamWriter.writeCharacters("James Elliott");
			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeEndElement();
			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeEndElement();

			xmlStreamWriter.writeEndDocument();
			xmlStreamWriter.close();

			Statement stmt = connection.createStatement();
			stmt
					.executeUpdate("CREATE Table Catalog(CatalogId int, Catalog XML)");

			PreparedStatement statement = connection
					.prepareStatement("INSERT INTO CATALOG(catalogId, catalog) VALUES(?,?)");

			statement.setInt(1, 1);
			statement.setSQLXML(2, sqlXML);

			statement.executeUpdate();
			sqlXML.free();

		} catch (SQLException e) {
		} catch (XMLStreamException e) {
		}

	}

	public void retrieveXMLDocument() {

		try {
			PreparedStatement stmt = connection
					.prepareStatement("SELECT * FROM  CATALOG WHERE catalogId=?");
			stmt.setInt(1, 1);

			ResultSet rs = stmt.executeQuery();

			SQLXML sqlXML = rs.getSQLXML("catalog");
			System.out.println(sqlXML.getString());
			
			InputStream binaryStream = sqlXML.getBinaryStream();
			XMLInputFactory factory = XMLInputFactory.newInstance();
			XMLStreamReader xmlStreamReader = factory.createXMLStreamReader(binaryStream);

			
			
			while (xmlStreamReader.hasNext()) {
				int parseEvent = xmlStreamReader.next();
				if (parseEvent == XMLStreamConstants.ATTRIBUTE) {
					System.out.println("ATTRIBUTE");
					System.out.println("Attribute Local Name: "
							+ xmlStreamReader.getAttributeLocalName(0));
					System.out.println("Attribute Namespace: "
							+ xmlStreamReader.getAttributeNamespace(0));
					System.out.println("Attribute Prefix: "
							+ xmlStreamReader.getAttributePrefix(0));
					System.out.println("Attribute Value: "
							+ xmlStreamReader.getAttributeValue(0));

				}
				if (parseEvent == XMLStreamConstants.CDATA) {
					System.out.println("CDATA");
					System.out.println("Text: " + xmlStreamReader.getText());
				}
				if (parseEvent == XMLStreamConstants.CHARACTERS) {
					System.out.println("CHARACTERS");
					System.out.println("Text: " + xmlStreamReader.getText());
				}
				if (parseEvent == XMLStreamConstants.COMMENT) {
					System.out.println("COMMENT");
					System.out.println("Text: " + xmlStreamReader.getText());
				}
				if (parseEvent == XMLStreamConstants.NOTATION_DECLARATION) {
					System.out.println("NOTATION_DECLARATION");
				}
				if (parseEvent == XMLStreamConstants.START_DOCUMENT) {
					System.out.println("START_DOCUMENT");
				}
				if (parseEvent == XMLStreamConstants.START_ELEMENT) {
					System.out.println("START_ELEMENT");
					System.out.println("Local Name: "
							+ xmlStreamReader.getLocalName());
					System.out.println("Text: "
							+ xmlStreamReader.getElementText());
					System.out
							.println("Prefix: " + xmlStreamReader.getPrefix());
					System.out.println("Namespace: "
							+ xmlStreamReader.getNamespaceURI());
				}
				if (parseEvent == XMLStreamConstants.END_ELEMENT) {
					System.out.println("END_ELEMENT");
					System.out.println("Local Name: "
							+ xmlStreamReader.getLocalName());
				}
				if (parseEvent == XMLStreamConstants.ENTITY_DECLARATION) {
					System.out.println("ENTITY_DECLARATION");
				}
				if (parseEvent == XMLStreamConstants.ENTITY_REFERENCE) {
					System.out.println("ENTITY_REFERENCE");
					System.out.println("Text: "
							+ xmlStreamReader.getElementText());
				}
				if (parseEvent == XMLStreamConstants.NAMESPACE) {
					System.out.println("NAMESPACE");
					System.out.println("Prefix: "
							+ xmlStreamReader.getNamespacePrefix(0));
					System.out.println("NamespaceURI: "
							+ xmlStreamReader.getNamespaceURI(0));

				}
				if (parseEvent == XMLStreamConstants.SPACE) {
					System.out.println("SPACE");
					System.out.println("Text: " + xmlStreamReader.getText());

				}
				if (parseEvent == XMLStreamConstants.END_DOCUMENT) {
					System.out.println("END_DOCUMENT");
				}
				if (parseEvent == XMLStreamConstants.DTD) {
					System.out.println("DTD");
				}

			}

			sqlXML.free();

		} catch (SQLException e) {
		}catch (XMLStreamException e) {
		}

	}

	public static void main(String[] argv) {
		XMLToSQL sqlXMLApp = new XMLToSQL();
		sqlXMLApp.createJDBCConnection();

		/*
		 * sqlXMLApp.storeXMLDocument(); 
		 * sqlXMLApp.retrieveXMLDocument();
		 */
	}
}
