package com.apress.jaxb;


import generated.*;
import javax.xml.bind.*;



public class JAXBMarshaller {
	public void generateXMLDocument() {
		try {

			JAXBContext jaxbContext = JAXBContext.newInstance("generated");
			Marshaller marshaller = jaxbContext.createMarshaller();
			generated.ObjectFactory factory = new generated.ObjectFactory();

			Catalog catalog = factory.createCatalog();
			catalog.setSection("Java Technology");
			catalog.setPublisher("IBM developerWorks");

			Journal journal = factory.createJournal();
			Article article = factory.createArticle();

			article.setLevel("Intermediate");
			article.setDate("January-2004");
			article.setTitle("Service Oriented Architecture   Frameworks");
			article.setAuthor("Naveen Balani");

			java.util.List journalList = catalog.getJournal();
			journalList.add(journal);
			java.util.List articleList = journal.getArticle();
			articleList.add(article);

			article = factory.createArticle();

			article.setLevel("Advanced");
			article.setDate("October-2003");
			article.setTitle("Advance DAO Programming");
			article.setAuthor("Sean Sullivan");

			articleList = journal.getArticle();
			articleList.add(article);

			article = factory.createArticle();

			article.setLevel("Advanced");
			article.setDate("May-2002");
			article.setTitle("Best Practices in EJB   Exception Handling");
			article.setAuthor("Srikanth Shenoy");
			articleList = journal.getArticle();

			articleList.add(article);
			marshaller.setProperty("jaxb.formatted.output",Boolean.TRUE);
			marshaller.marshal(catalog, System.out);

		}  catch (JAXBException e) {
			System.out.println(e.toString());

		}

	}

	public static void main(String[] argv) {
		JAXBMarshaller jaxbMarshaller = new JAXBMarshaller();
		jaxbMarshaller.generateXMLDocument();
	}
}
