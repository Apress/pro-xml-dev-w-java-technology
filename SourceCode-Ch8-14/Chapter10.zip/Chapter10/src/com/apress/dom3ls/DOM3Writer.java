package com.apress.dom3ls;

import org.w3c.dom.*;
import org.w3c.dom.bootstrap.DOMImplementationRegistry;
import org.w3c.dom.ls.*;



import javax.xml.parsers.*;

public class DOM3Writer {
                                       
                                     //Method to save an XML document
	public void saveDocument() {
		try {      //Create an XML Document
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();

			Document document = builder.newDocument();
			Element catalog = document.createElement("catalog");

			catalog.setAttribute("publisher", "IBM developerWorks");

			document.appendChild(catalog);

			Element journal = document.createElement("journal");

			journal.setAttribute("edition", "October 2005");

			journal.setAttribute("section", "XML");

			catalog.appendChild(journal);

			Element article = document.createElement("article");
			journal.appendChild(article);

			Element title = document.createElement("title");

			title.appendChild(document.createTextNode("JAXP Validation"));
			article.appendChild(title);

			Element author = document.createElement("author");

			author.appendChild(document.createTextNode("Brett McLaughlin"));
			article.appendChild(author);
               //Set system property for DOMImplementationRegistry

	System.setProperty(DOMImplementationRegistry.PROPERTY,
				"org.apache.xerces.dom.DOMImplementationSourceImpl");
                                       //Create a DOMImplementationRegistry object
			DOMImplementationRegistry registry = DOMImplementationRegistry
					.newInstance();
                                       //Create a DOMImplementation object
		DOMImplementation domImpl = registry.getDOMImplementation("LS 3.0");

			DOMImplementationLS implLS = (DOMImplementationLS) domImpl;
                                       //Create a LSSerializer Object
			LSSerializer dom3Writer = implLS.createLSSerializer();
                                       //Create a LSOutput Object
			LSOutput output = implLS.createLSOutput();

			System.out.println("Outputting XML Document");
			output.setByteStream(System.out);

			output.setEncoding("UTF-8");
                                      //Output the XML document
			dom3Writer.write(document, output);

			System.out.println("\n\n"+"Outputting the journal Node"+"\n");
                                       //Output a node			
			dom3Writer.write(journal, output);
                                       //Output a node to String
			String nodeString = dom3Writer.writeToString(journal);

			
		}  catch (ParserConfigurationException e) {
		} catch (ClassNotFoundException e) {
		} catch (InstantiationException e) {
		} catch (IllegalAccessException e) {
		}
	}

	public static void main(String[] argv) {

		DOM3Writer dom3Writer = new DOM3Writer();
		dom3Writer.saveDocument();
	}
}


