package com.apress.dom3ls;
import org.w3c.dom.*;
import org.w3c.dom.bootstrap.*;
import org.w3c.dom.ls.*;


public class DOM3Builder {
                                      //Method to load an XML document
	public void loadDocument() {
		try {       //Setting system property for DOMImplementationRegistry
			System.setProperty(DOMImplementationRegistry.PROPERTY,
				"org.apache.xerces.dom.DOMImplementationSourceImpl");
                                       //Creating a DOMImplementationRegistry
			DOMImplementationRegistry registry = DOMImplementationRegistry
					.newInstance();
                                       //Creating a DOMimplementation object. 
		DOMImplementation domImpl = registry.getDOMImplementation("LS 3.0");
                                        //Casting DOMImplementation to DOMImplementationLS
			DOMImplementationLS implLS = (DOMImplementationLS) domImpl;
                                        //Creating a LSParser object. 
			LSParser parser = implLS.createLSParser(
					DOMImplementationLS.MODE_SYNCHRONOUS,
					"http://www.w3.org/2001/XMLSchema");
                                       //Obtaining a DOMConfiguration object
			DOMConfiguration config = parser.getDomConfig();
                                       //Setting the error handler
			DOMErrorHandlerImpl errorHandler = new DOMErrorHandlerImpl();

			config.setParameter("error-handler", errorHandler);
                                        //Setting schema validation parameters
			config.setParameter("validate", Boolean.TRUE);

			config.setParameter("schema-type",
					"http://www.w3.org/2001/XMLSchema");

			config.setParameter("validate-if-schema", Boolean.TRUE);
			config.setParameter("schema-location", "catalog.xsd");
                                       //Parsng an XML document
			Document document = parser.parseURI("catalog.xml");
			System.out.println("XML document loaded");
		} catch (DOMException e) {
			System.out.println("DOMException " + e.getMessage());
		} catch (ClassNotFoundException e) {
			System.out.println("ClassNotFoundException " + e.getMessage());
		} catch (InstantiationException e) {
			System.out.println("InstantiationException " + e.getMessage());
		} catch (IllegalAccessException e) {
			System.out.println("IllegalAccessException " + e.getMessage());
		}
	}

	public static void main(String[] args) {
		DOM3Builder dom3Builder = new DOM3Builder();
		dom3Builder.loadDocument();
	}
               //Error handler class
	private class DOMErrorHandlerImpl implements DOMErrorHandler {
		public boolean handleError(DOMError error) {
			System.out.println("Error Message:" + error.getMessage());

			if (error.getSeverity() == DOMError.SEVERITY_WARNING) {
				return true;
			} else {
				return false;
			}
		}
	}
}

