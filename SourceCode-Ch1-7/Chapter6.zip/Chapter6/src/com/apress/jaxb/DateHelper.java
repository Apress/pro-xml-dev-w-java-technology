package com.apress.jaxb;

import java.text.*;
import java.util.*;
public class DateHelper {
 private final static SimpleDateFormat df = new 

SimpleDateFormat("yyyy-MM-dd");
 
 public static String format(Date date) {
  return df.format(date);
 }
 
 public static Date parse(String datestr) {
  Date date = null;
  try {
  date= df.parse(datestr);
  } catch(Exception e) {
   
  }
  return date;
 }
}
