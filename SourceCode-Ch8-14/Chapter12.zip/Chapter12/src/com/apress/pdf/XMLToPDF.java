package com.apress.pdf;

import org.apache.fop.apps.*;
import org.apache.avalon.framework.logger.*;
import java.io.*;
import org.xml.sax.InputSource;
import javax.xml.parsers.*;
import org.xml.sax.*;
import org.w3c.dom.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.*;
import javax.xml.transform.stream.*;

public class XMLToPDF {
	public void generateXSLFO(File xmlFile, File xsltFile) {
		try {
			System.setProperty("javax.xml.parsers.DocumentBuilderFactory",
					"org.apache.xerces.jaxp.DocumentBuilderFactoryImpl");
			System.setProperty("javax.xml.transform.TransformerFactory",
					"org.apache.xalan.processor.TransformerFactoryImpl");
			// Create a DocumentBuilderFactory
			DocumentBuilderFactory factory = DocumentBuilderFactory
					.newInstance();
			// Create File object for input XSLT and example XML document.

			// Create DocumentBuilder object
			DocumentBuilder builder = factory.newDocumentBuilder();
			// Parse example XML Document
			Document document = builder.parse(xmlFile);
			// Create a TransformerFactory object
			TransformerFactory tFactory = TransformerFactory.newInstance();

			// Create a Stylesource object from the stylesheet File object.
			StreamSource stylesource = new StreamSource(xsltFile);

			// Create a Transformer object from the StyleSource object
			Transformer transformer = tFactory.newTransformer(stylesource);
			// Create a DOMSource object from an XML document

			DOMSource source = new DOMSource(document);
			// Create a StreamResult object to output the result of a
			// transformation.
			StreamResult result = new StreamResult("catalog.fo");

			// Transform an XML document with an XSLT stylesheet
			transformer.transform(source, result);

		} catch (TransformerConfigurationException e) {

			System.out.println(e.getMessage());

		} catch (TransformerException e) {

			System.out.println(e.getMessage());
		} catch (SAXException e) {
			System.out.println(e.getMessage());

		} catch (ParserConfigurationException e) {

			System.out.println(e.getMessage());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}

	}

	public void generatePDF() {
		try {
			Driver driver = new Driver();
			Logger logger = new ConsoleLogger(ConsoleLogger.LEVEL_INFO);
			driver.setLogger(logger);
			org.apache.fop.messaging.MessageHandler.setScreenLogger(logger);
			driver.setRenderer(Driver.RENDER_PDF);
			
			InputStream input = new FileInputStream(new File("catalog.fo"));
			driver.setInputSource(new InputSource(input));
			OutputStream output = new FileOutputStream(new File("catalog.pdf"));
			driver.setOutputStream(output);

			driver.run();
			output.flush();
			output.close();
		} catch (IOException e) {
		} catch (org.apache.fop.apps.FOPException e) {
			System.out.println(e.getMessage());
		}

	}

	public static void main(String[] argv) {

		XMLToPDF xmlToPDF = new XMLToPDF();
		File xmlFile = new File("catalog.xml");
		File xsltFile = new File("catalog.xslt");
	
		
		xmlToPDF.generateXSLFO(xmlFile, xsltFile);
		xmlToPDF.generatePDF();

	}
}
